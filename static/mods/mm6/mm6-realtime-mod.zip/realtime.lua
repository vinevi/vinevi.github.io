-- Realtime mod v0.1
-- Removes pause from most of the game aspects 

mem.nop(0x00425ff8) -- cast spell

mem.nop(0x004194b6) -- cast spell - select target

mem.nop(0x0042cd8a) -- cast screen

mem.nop(0x0042bef4) -- options screen

mem.nop(0x0042ce35) -- quick reference screen

mem.nop(0x0043be6b) -- talk to NPC
mem.nop(0x0043be75)

mem.nop(0x00411468) -- right click

mem.nop(0x0041ea19) -- chest screen

mem.nop(0x004a63f9) -- house cinematics

mem.nop(0x0041fa80) -- character screen

mem.nop(0x0043a0fe) -- dungeon entrance screen

mem.nop(0x0041d59b) -- rest screen

mem.nop(0x0043a4e8) -- map transition screen
mem.asmhook(0x0045c5e9, "CALL absolute 0x0043c100") -- remove the map transition viewport (if there is one) before creating a new one

mem.asmpatch(0x0043525c, "JMP absolute 0x00435267") -- skip screen index check when rendering
													-- allows to keep rendering during NPC conversations, map transitions and such

mem.asmpatch(0x0042b152, "JMP absolute 0x0042b162") -- disable turn-based mode

-- on death
-- this takes care of removing UI elements / screens on death
-- if the party died when looking through inventory, map transition screens and such
mem.asmhook(0x00453ce3, [[
	MOV ECX,dword ptr [0x004d50cc] ; Remove options viewport
	CALL absolute 0x004190d0
	CALL absolute 0x0043c100 ; Remove map transition viewport
]])