Realtime mod for Might & Magic VI (MMExtension)

The mod removes the pause from gameplay mechanics.
https://vinevi.github.io/projects/mm6-realtime-mod

Installation:
  1. Install MMExtension: https://github.com/GrayFace/MMExtension
  2. Copy-paste realitme.lua into the /scripts/general directory
