Might and Magic VII solo script v1.0

Description:
Eradicates the 2, 3 and 4th character slots when starting a new game.

Installation:
Use MMArchive 
https://grayface.github.io/mm/#MMArchive
To open the /data/events.lod file and then add OUT01.EVT
which will replace the original file.
